
<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link
href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">


<link href="assets/css/listaHoraExtra.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">

<!-- BOOTSTRAP -->
<script src="assets/js/main.js"></script>
<script src="assets/js/bootstrap.min.js"></script>


<!-- JQUERY -->
<script src="assets/jquery/jquery-ui.min.js"></script>
<script src="assets/jquery/jquery.3.6.4.min.js"></script>


<!-- SWEETALERT -->
<script src="assets/sweetAlert/sweetAlert.js"></script>



<!-- PLUGIN datatables -->
<link rel="stylesheet" type="text/css" href="util/front/datatables-bs4/css/dataTables.bootstrap4.min.css" />
<link rel="stylesheet" type="text/css" href="util/front/datatables-responsive/css/responsive.bootstrap4.min.css" />
<script src="util/front/datatables/jquery.dataTables.min.js"></script>
<script src="util/front/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="util/front/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="util/front/datatables-responsive/js/responsive.bootstrap4.min.js"></script>



<!-- PLUGIN MAPA API MAPBOX -->
<link href="https://api.mapbox.com/mapbox-gl-js/v2.13.0/mapbox-gl.css" rel="stylesheet">
<script src="https://api.mapbox.com/mapbox-gl-js/v2.13.0/mapbox-gl.js"></script>