    <!-- ======= cabecalho ======= -->
    <header id="header" class="header fixed-top d-flex align-items-center">

        <div class="d-flex align-items-center justify-content-between">
            <a href="index.php" class="logo d-flex align-items-center">
                <span>Controle de Contas</span>
            </a>
        </div>


        <nav class="header-nav ms-auto row">
            <ul class="d-flex align-items-center">

                <li style="margin-right: 25px;">
                    <a href="logout.php" class="btn btn-danger">
                        <i class="bi bi-box-arrow-right"></i> Sair
                    </a>
                </li>

            </ul>
        </nav>
    </header>
    <!-- FIM CABECALHO-->